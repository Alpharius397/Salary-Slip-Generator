import io
from collections import defaultdict
import os
import sys
from tkinter import simpledialog,font
from typing import IO
import customtkinter as ctk
import tkinter as tk
import tkinter.messagebox as tkmb
from tkinter import filedialog, scrolledtext, Scrollbar,messagebox 
import pdfkit
import pyperclip
import pandas as pd
from database import dataRefine,Database,mapping,check_column,PandaGenerator,get_salary_column
from mail import Mailing
from html_style import HTML_CONTENT,DATA_CONTENT
import msoffcrypto
import re

# Set custom appearance and color theme
ctk.set_appearance_mode("light")  # The custom color theme will be applied manually

IS_EXE = True # when building .exe set to true
IS_DEBUG = False # for testing set to true
APP_PATH = __file__ if not IS_EXE else sys.executable
MYSQL_CRED = {'host':'localhost','user':'root','pass':'1234','db':'somaiya_salary'} # your mysql creds for testing (works if is_debug == True)
SMTP_CRED = {'email':'salary.tech@somaiya.edu','key':'mhenlcndnwonyadw'} if not IS_DEBUG else {'email':'rajjm397@gmail.com','key':'fjuygjqzmsutwfjt'}
email_regex = lambda x: True if re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', str(x)) else False # a helper function for email validation
year_check = lambda x: True if re.match(r'^(\d){4}$',x) else False # a helper function for year validation

prev_password = 'check'

class CustomPasswordDialog(simpledialog.Dialog):
    def __init__(self, parent=None, title=None):
        self.password = None
        super().__init__(parent, title=title)

    def body(self, master):
        
        custom_font = font.Font(family="Ubuntu", size=12)
        tk.Label(master, text="Enter Password for workbook: ",font=custom_font).grid(row=0, column=0, padx=20, pady=10)
        
        self.entry = tk.Entry(master, show="*", font=custom_font)
        self.entry.grid(row=1, column=0, padx=20, pady=10)
        
        return self.entry

    def apply(self):
        self.password = self.entry.get()

def ask_password(parent=None, title="Credential Entry"):
    dialog = CustomPasswordDialog(parent, title)
    return dialog.password

# contains pandas,excel and everything common functions
class ExcelFunc():
    
    # generate a pdf either in a user-location (single) or in application location in folder pdfs (bulk)
    def generate_pdf(self,emp_data:dict[str,str],month:str,year:int,type_:str,chosen:str,file:IO,bulk:bool) -> None:  
        
        try:
            if file is not None and not bulk:
                name = file.name
                file.close()
                os.remove(name)
                where= '/'.join(name.split('/')[:-1])

            elif bulk:
                try:
                    where = os.path.join(os.path.dirname(APP_PATH),'pdfs')
                    where = os.path.join(where,chosen)
                    where = os.path.join(where,type_)
                    where = os.path.join(where,year)
                    where = os.path.join(where,month)

                    os.makedirs(where)

                except OSError as e:
                    print('Directory exists')
            filename = f"employee_{emp_data['hr_emp']}.pdf"

            if (re.match(r'employee_(\w+\d+).pdf',filename)):
                pdf_file = os.path.join(where,filename)
                html_content = HTML_CONTENT + DATA_CONTENT(month,year,emp_data)
                pdfkit.from_string(html_content, pdf_file,options={
                            'page-size': 'A4',
                            'margin-top': '0.5in',
                            'margin-right': '0.5in',
                            'margin-bottom': '0.5in',
                            'margin-left': '0.5in',
                            'no-outline': None
                })
                
        except OSError as e:
            tkmb.showerror("Error", f"An error occurred while generating the PDF: {str(e)}")
        except Exception as e:
            tkmb.showerror("Error", f"An error occurred while generating the PDF: {str(e)}")

            

    # displays excels (panda dataframe) on app screen
    def view_excel(self) -> None:
        self.text_excel.delete(1.0, tk.END)

        data = [[i for i in self.data.columns]]
        for index,row in self.data.iterrows():
            row_data = [str(cell) for cell in row.values]
            data.append(row_data)

        col_widths = defaultdict(int)
        
        for col in data:
            for idx,cell in enumerate(col):
                col_widths[idx] = max(col_widths[idx],len(str(cell)))
        replace_new = lambda x: x.replace('\n',"")
        
        formatted_data = "\n".join([" " + " | ".join([f"{replace_new(cell):^{col_widths[i]}}" for i, cell in enumerate(row)]) + " " for row in data])
        
        self.text_excel.insert(tk.END, formatted_data)

    # changes type of slip for selected institue
    def changeType(self,event:tk.Event=None) -> None:
        institute = self.chosen.get()
        self.toggle_type.configure(values = list(self.outer.toggle_type[institute]))
        self.type_.set(list(self.outer.toggle_type[institute])[0])

    # dynamically changes to show all sheets of a excel file
    def changeSheets(self,event:tk.Event=None) -> None:
        self.sheetList.configure(values=self.sheets)

    # updates the display of excel file
    def changeView(self,event:tk.Event=None,skip:int=0) -> None:
        self.data = pd.read_excel(self.decryting_wrapper(self.file.get(),prev_password),sheet_name=self.sheet.get(),skiprows=skip)
        dataRefine(self.data)
        self.view_excel()

    # checks db for existing data
    def load_database(self,month:str,year:int,chosen:str,type_:str)-> bool:
        db = self.outer.db
        if db.status:
            
            self.data=db.fetchAll(month,year,chosen,type_)
            
            if self.data is not None and len(self.data.columns)>0:
                self.view_excel()
                return True

            else:
                return False
            
        else:
            tkmb.showerror("MySQL Error","MySQL error occured")
        
        return db.status

    # prints all emp_id in sheet
    def bulk_print_pdfs(self,employee_data:pd.DataFrame,month:str,year:int,type_:str,chosen:str) -> None:
        code = mapping(pd_columns=employee_data.columns,columns='hr emp code')
        pd_columns = sorted(employee_data.columns,key=len)
        col_map = get_salary_column(pd_columns)
        memo = {j:i for i,j in enumerate(employee_data.columns)}
        if code:
            for i in employee_data.itertuples(index=False):
                emp_data = {key:i[memo[val]] if val else val for key,val in col_map.items()}
                self.generate_pdf(emp_data,month,year,type_,chosen,None,True)
            tkmb.showinfo("Bulk Print", "Bulk PDF generation completed.")
        else:
            tkmb.showwarning("Error", "HR EMP CODE column cannot be found!.")
            

    # extracts data of a particular employee
    def extract_data(self,employee_data:pd.DataFrame,month:str,year:int,type_:str,chosen:str,who:str) -> None:
        code = mapping(pd_columns=employee_data.columns,columns='hr emp code')
        pd_columns = sorted(employee_data.columns,key=len)
        
        if code:
            employee_data = employee_data[employee_data[code]==who]

            if employee_data.shape[0]:
                
                emp_data = {key:employee_data[val].values[0] if val else val for key,val in get_salary_column(pd_columns).items()}
                if self.saveLocation(month=month,year=year,type_=type_,chosen=chosen,who=who,emp_data=emp_data):
                    tkmb.showinfo("Single Print", "PDF generation completed.")
            else:
                tkmb.showwarning("Error", "Employee ID not found.")
        else:
            tkmb.showwarning("Error", "HR EMP CODE column cannot be found!.")

    # copy the data of a choosen employee
    def copy_row_to_clipboard(self) -> None:
        employee_id = self.entry_id.get()
        id = mapping(self.data,'hr emp code')
        
        if id and employee_id:
            search = self.data[self.data[id]==employee_id]

            if search.shape[0]:
                pyperclip.copy(','.join(search.values[0]))
                tkmb.showinfo("Copy Row", "Employee data copied to clipboard.")
            else:
                tkmb.showwarning("Error", "Employee ID not found.")
        elif id:
            tkmb.showerror("Empty Data","Empty Search String Detected")
        else:
            tkmb.showwarning("Error", "HR EMP CODE column cannot be found!.")
            
    # ask for save location for pdf
    def saveLocation(self,chosen:str,type_:str,month:str,year:int,who:int,emp_data:dict[str,str]) -> bool:
        file = None
        try:
            file = filedialog.asksaveasfile(initialfile=f"employee_{who}",defaultextension=".pdf",filetypes=[("PDF File","*.pdf")])
        
        
        except Exception as e:
            tkmb.showwarning("Error",f"Some error has occured: {e}")
            file = None
        
        if file:
            self.generate_pdf(emp_data,month,year,type_,chosen,file,False)
            return True
        else:
            tkmb.showinfo("Error","PDF Generation Failed")
            return False
        
    def decryting_wrapper(self,file_path:str,password:str='check'):
        global prev_password
        
        with open(file_path, "rb") as f:
            try:
                decrypted = io.BytesIO()

                file = msoffcrypto.OfficeFile(f)
                file.load_key(password=password)  
                file.decrypt(decrypted)
                
                return decrypted
            
            except msoffcrypto.exceptions.InvalidKeyError:
                
                decrypted = io.BytesIO()
                
                try:
                    _password = ask_password(title="Credential Entry") or "check"
                    file.load_key(password=_password)  
                    file.decrypt(decrypted)
                    prev_password = _password
                    
                except Exception as e:
                    print(e)
                    tkmb.showerror("Error", f"Incorrect Password")
                    
                return decrypted
            
            except msoffcrypto.exceptions.DecryptionError:
                return file_path

            except:
                return file_path

# an abstract for mail
class MailSending():
    def __init__(self,toAddr:str=None,month:str=None,year:int=None,pdf_location:str=None,type_:str=None,insti:str=None) -> None:
        self.toAddr = toAddr
        self.month = month
        self.year = year
        self.pdf_location = pdf_location
        self.type_ = type_
        self.insti = insti
    
    # attempts single mail
    def attemptMail(self) -> None:
        try:
            with open(self.pdf_location,'rb') as f:
                id = self.pdf_location.split('_')[-1].split('.pdf')[0]
                if Mailing(SMTP_CRED["email"],SMTP_CRED["key"]).login().addTxtMsg(f"Please find attached below the salary slip of {self.month.capitalize()}-{self.year}",'plain').addAttach(self.pdf_location,f'employee_{id}.pdf').addDetails(f"Salary slip of {self.month.capitalize()}-{self.year}").sendMail(self.toAddr).destroy().status:
                    tkmb.showinfo('Email Status','Email was send successfully!')
                else:
                    tkmb.showinfo('Email Status','Email was not send successfully!')
                    
        except FileNotFoundError as e:
            tkmb.showwarning('File not found',f'File {self.pdf_location} was not found!')
        except Exception as e:
            tkmb.showerror('Something went wrong',f'Error occured {e}')

    # attempts bulk mail
    def massMail(self,data:pd.DataFrame,code_column:str,email_col:str,pdf_path:str) -> None:

            count = 0
            attempt = Mailing(SMTP_CRED["email"],SMTP_CRED["key"]).login()
            data = PandaGenerator(data,code_column)
            file_regex = r'employee_(\d+).pdf$'
            total = 0
            try:
                mails = os.listdir(pdf_path)

                if mails:
                    for mail in mails:
                        try:
                            find = re.findall(file_regex,mail)
                            if not find: continue
                            total+=1
                            id = find[0]
                            path = os.path.join(pdf_path,mail)
                            if not (os.path.isfile(path)):
                                continue
                            toAddr = data[id][email_col].values[0]
                            if attempt.addTxtMsg(f"Please find attached below the salary slip of {self.month.capitalize()}-{self.year}",'plain').addAttach(path,f'employee_{id}.pdf').addDetails(f"Salary slip of {self.month.capitalize()}-{self.year}").sendMail(toAddr).resetMIME().status:
                                count+=1

                        except Exception as e:
                            print(e)

                    if count:
                        tkmb.showinfo('Email Status',f'{count}/{total} emails were send successfully!')
                    else:
                        tkmb.showinfo('Email Status',f'No emails were send!')

                else:
                    tkmb.showinfo('Email Status',f'No files were found!')

            except FileNotFoundError:
                tkmb.showwarning('File not found',f'File {pdf_path} was not found!')

            except Exception as e:
                tkmb.showwarning('Error',f'Something went wrong : {e}')
            
            attempt.destroy()

# base template for every tkinter applications
class BaseTemplate():

    def check_attribute(self):
        if(hasattr(self,'frame') and hasattr(self,'visible')):
            return True
        else:
            return False
    
    # makes only the current frame visible 
    def appear(self) -> None:
        if(self.check_attribute() and isinstance(self.frame,ctk.CTkScrollableFrame)):
            if not self.visible:            
                self.frame.pack(pady=20, padx=40, fill='both', expand=True)
                self.visible = True
            else:
                print(' Already Visible')
        else:
            print(" Object doesn't have frame attribute")

    # hides the current frame
    def hide(self) -> None:
        if(self.check_attribute() and isinstance(self.frame,ctk.CTkScrollableFrame)):        
            if self.visible:
                self.frame.pack_forget()
                self.visible = False
            else:
                print(' Already hidden')
        else:
            print(" Object doesn't have frame attribute")
        
# Initialize main application
class App():
    def __init__(self) -> None:
        self.app:ctk.CTk = ctk.CTk()
        self.app.geometry(f"{500}x{500}")
        self.app.title("Salary-slip Generator")
        self.toggle_type:dict[str,list[str]] = {'Somaiya':['Teaching','NonTeaching','Temporary'],'SVV':['svv']}
        self.cred:dict = defaultdict(lambda : None)
        self.children:dict[str,DataSet|SendMail|SendMails|Login|FileInput|Landing|Interface|DBFetch|DBUpload|Mail] = {'DataSet':DataSet(self),'SendMail':SendMail(self),'SendMails':SendMails(self),'Login':Login(self),'FileInput':FileInput(self),'Landing':Landing(self),'Interface':Interface(self),'DBFetch':DBFetch(self),'DBUpload':DBUpload(self),'Mail':Mail(self)}
        self.month_order:dict[str,int] = {"jan":1, "feb":2, "mar":3, "apr":4, "may":5, "jun":6, "jul":7, "aug":8, "sept":9, "oct":10, "nov":11, "dec":12}
        self.children[Login.__name__].appear()
        self.db = Database()

# contains mail options
class Mail(BaseTemplate):
    def __init__(self,outer:App):
        self.outer = outer
        self.visible = False
        
        master = self.outer.app
        self.frame = ctk.CTkScrollableFrame(master=master, fg_color=custom_color_scheme["fg_color"])        
        
        ctk.CTkLabel(master=self.frame , text="Select mailing option", text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=10)
        ctk.CTkButton(master=self.frame, text='Single Mail', command=self.single, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=12, padx=10)
        ctk.CTkButton(master=self.frame, text='Bulk Mail', command=self.many, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=12, padx=10)
        ctk.CTkButton(master=self.frame, text='Back', command=self.back_to_landing, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=12, padx=10)

    # redirects to single mail
    def single(self) -> None:
        self.hide()
        self.outer.children[SendMail.__name__].changeType()
        self.outer.children[SendMail.__name__].appear()
    
    # redirects to multiple mail
    def many(self) -> None:
        self.hide()
        self.outer.children[SendMails.__name__].changeType()
        self.outer.children[SendMails.__name__].appear()

    # back to landing
    def back_to_landing(self) -> None:
        self.hide() 
        self.outer.children[Landing.__name__].appear()

# sends a single mai
class SendMail(BaseTemplate,ExcelFunc):
    def __init__(self,outer:App):
        self.outer = outer
        master = self.outer.app
        self.frame = ctk.CTkScrollableFrame(master=master, fg_color=custom_color_scheme["fg_color"])
        self.chosen = ctk.StringVar()
        self.type_ = ctk.StringVar()
        self.month = ctk.StringVar()
        self.visible = False
        
        self.type_.set('Teaching')
        self.chosen.set('Somaiya')
        self.month.set('Jan')
        
        ctk.CTkLabel(master=self.frame , text="Single Mail", text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=10)
        ctk.CTkLabel(master=self.frame , text="Select PDF File:", text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=10)
        
        self.file = ctk.CTkEntry(master=self.frame , width=100, text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"))
        self.file.pack(pady=5)
        
        ctk.CTkButton(master=self.frame , text="Browse", command=self.select_file, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=5)
        ctk.CTkOptionMenu(master=self.frame,variable=self.chosen,values=["Somaiya", "SVV"],command=self.changeType,button_color=custom_color_scheme["button_color"],fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=12, padx=10)
        
        self.toggle_type = ctk.CTkOptionMenu(master=self.frame,variable=self.type_,values=[],button_color=custom_color_scheme["button_color"],fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250)
        self.toggle_type.pack(pady=12, padx=10)
        
        ctk.CTkOptionMenu(master=self.frame,variable=self.month,values=["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"],button_color=custom_color_scheme["button_color"],fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=12, padx=10)
        ctk.CTkLabel(master=self.frame , text="Enter Year:", text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold")).pack()
        
        self.year = ctk.CTkEntry(master=self.frame ,placeholder_text="Eg. 2024", text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250)
        self.year.pack()
        
        ctk.CTkLabel(master=self.frame , text="Enter Employee Email:", text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold")).pack()
        
        self.email = ctk.CTkEntry(master=self.frame , placeholder_text="Eg. asd@somaiya.edu",text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250)
        self.email.pack()
        
        ctk.CTkButton(master=self.frame , text='Send Mail', command=self.send, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=12,padx=10)
        ctk.CTkButton(master=self.frame , text='Back', command=self.back, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=12, padx=10)

    # select file dialog
    def select_file(self) -> None:
        file_path = filedialog.askopenfilename(filetypes=[("PDF Files", ".pdf")],initialdir=APP_PATH)
        if file_path:
            self.file.delete(0, tk.END)
            self.file.insert(0, file_path)
            self.file.configure(width=7*len(file_path))

    # back button
    def back(self) -> None:
        self.hide()
        self.outer.children[Mail.__name__].appear()
        
    # send button
    def send(self) -> None:
        to_email = self.email.get()
        year = self.year.get()
        month = self.month.get().lower()
        path = self.file.get()
        
        if year_check(year):
            year = int(year)
        else:
            tkmb.showwarning("Alert","Incorrect year format")
            return
            
        if email_regex(to_email):
            MailSending(toAddr=to_email,month=month,year=year,pdf_location=path).attemptMail()
        else:
            tkmb.showwarning("Alert","Incorrect email format")

# sends bulk email
class SendMails(BaseTemplate,ExcelFunc):
    def __init__(self,outer:App):
        self.outer = outer
        self.chosen = ctk.StringVar()
        self.month = ctk.StringVar()
        self.type_ = ctk.StringVar()
        self.visible = False

        self.type_.set('Teaching')
        self.chosen.set('Somaiya')
        self.month.set('Jan')
        
        master = self.outer.app
        self.frame = ctk.CTkScrollableFrame(master=master, fg_color=custom_color_scheme["fg_color"])

        
        ctk.CTkLabel(master=self.frame, text="Bulk Mail", text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=10)
        ctk.CTkLabel(master=self.frame, text="Select Folder Location:", text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=20)
        self.folder = ctk.CTkEntry(master=self.frame , text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250)
        self.folder.pack()

        ctk.CTkButton(master=self.frame , text='Browse', command=self.folder_browse, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=12, padx=10)
        ctk.CTkOptionMenu(master=self.frame,variable=self.chosen,values=["Somaiya", "SVV"],command=self.changeType,button_color=custom_color_scheme["button_color"],fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=12, padx=10)
        
        self.toggle_type = ctk.CTkOptionMenu(master=self.frame,variable=self.type_,values=[],button_color=custom_color_scheme["button_color"],fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250)
        self.toggle_type.pack(pady=12, padx=10)
        
        ctk.CTkOptionMenu(master=self.frame,variable=self.month,values=["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"],button_color=custom_color_scheme["button_color"],fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=12, padx=10)
        ctk.CTkLabel(master=self.frame , text="Enter Year:", text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold")).pack()

        self.year = ctk.CTkEntry(master=self.frame , placeholder_text="Eg. 2024",text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250)
        self.year.pack()
        
        ctk.CTkButton(master=self.frame , text='Send Emails', command=self.sendEvery, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=12, padx=10)
        ctk.CTkButton(master=self.frame , text='Back', command=self.button_mailing, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=12, padx=10)

    # back button
    def button_mailing(self) -> None:
        self.hide()
        self.outer.children[Mail.__name__].appear()

    # fetches data from the chosen table
    def sendEvery(self) -> None:
        month = self.month.get().lower()
        year = self.year.get()
        chosen = self.chosen.get().lower()
        type_ = self.type_.get().lower()
        pdf_path = self.folder.get()
        
        if year_check(year):
            data = self.outer.db.fetchAll(month,year,chosen,type_)
        else:
            tkmb.showwarning("Alert","Incorrect year format")
            return
            
        if data is not None:
            email_col = mapping(data,'email mail')
            code_col = mapping(data,'hr emp code')

            if email_col and code_col:
                MailSending(month=month,year=year,type_=type_,insti=chosen).massMail(data,code_col,email_col,pdf_path)
            else:
                tkmb.showerror('Data Status','Data in DB does not have either HR EMP CODE/Email column')

        else:
            tkmb.showerror('Data Status','Data is not present in DB.\n Please upload data to DB')

    # select folder that contains pdf
    def folder_browse(self) -> None:
        current_dir = os.path.dirname(APP_PATH)
        entry_folder = filedialog.askdirectory(initialdir=current_dir)

        if entry_folder:
            self.folder.delete(0,tk.END)
            self.folder.insert(0,entry_folder)
            self.folder.configure(width=7*len(entry_folder))

# the mysql form page
class DataSet(BaseTemplate):
    def __init__(self,outer:App) -> None:
        self.visible = False
        self.outer = outer
        master = self.outer.app
        self.frame = ctk.CTkScrollableFrame(master=master, fg_color=custom_color_scheme["fg_color"])

        ctk.CTkLabel(master=self.frame, text='MySQL Connection', text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=20)
        
        self.host= ctk.CTkEntry(master=self.frame, placeholder_text="Host", text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250)
        self.host.insert(0,"localhost")
        self.host.pack(pady=12, padx=10)

        self.user = ctk.CTkEntry(master=self.frame, placeholder_text="User", text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250)
        self.user.insert(0,"root")
        self.user.pack(pady=12, padx=10)
        
        self.password = ctk.CTkEntry(master=self.frame, placeholder_text="Password", show="*", text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250)
        self.password.pack(pady=12, padx=10)

        self.db = ctk.CTkEntry(master=self.frame, placeholder_text="Database", text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250)
        self.db.pack(pady=12, padx=10)
        
        ctk.CTkButton(master=self.frame, text='Continue', command=self.next, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=12, padx=10)
        ctk.CTkButton(master=self.frame, text='Back', command=self.back, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=12, padx=10)

    # back to login page
    def back(self):
        self.hide()
        self.outer.children[Login.__name__].appear()

    # moves to next page (landing) is mysql connection was established
    def next(self):
        self.outer.cred['host'] = self.host.get() if not IS_DEBUG else MYSQL_CRED['host']
        self.outer.cred['user'] = self.user.get() if not IS_DEBUG else MYSQL_CRED['user']
        self.outer.cred['pass'] = self.password.get() if not IS_DEBUG else MYSQL_CRED['pass']
        self.outer.cred['db'] = self.db.get() if not IS_DEBUG else MYSQL_CRED['db']

        if self.outer.db.connectDatabase(host=self.outer.cred['host'],user=self.outer.cred['user'],password=self.outer.cred['pass'],database=self.outer.cred['db']).status:
            tkmb.showinfo("MySQL Status", "Connection established")
            self.hide()
            self.outer.children[Landing.__name__].appear()
        
        else:
            tkmb.showinfo("MySQL Status", "No Connection established")

# login screen
class Login(BaseTemplate):
    def __init__(self,outer:App) -> None:
        self.outer = outer
        self.visible = False
        master = self.outer.app
        
        self.frame = ctk.CTkScrollableFrame(master=master, fg_color=custom_color_scheme["fg_color"])

        ctk.CTkLabel(master=self.frame, text='Admin login page', text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=20)

        self.user_entry = ctk.CTkEntry(master=self.frame, placeholder_text="Username", text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250)
        self.user_entry.pack(pady=12, padx=10)

        self.user_pass = ctk.CTkEntry(master=self.frame, placeholder_text="Password", show="*", text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250)
        self.user_pass.pack(pady=12, padx=10)

        self.button_login = ctk.CTkButton(master=self.frame, text='Login', command=self.login, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250)
        self.button_login.pack(pady=12, padx=10)

        self.button_quit = ctk.CTkButton(master=self.frame, text='Exit', command=self.quit, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250)
        self.button_quit.pack(pady=12, padx=10)

    # login function
    def login(self) -> None:
        known_user = 'admin'
        known_pass = 'kjs2024'
        username = self.user_entry.get() if not IS_DEBUG else known_user
        password = self.user_pass.get() if not IS_DEBUG else known_pass

        if known_user == username and known_pass == password:
            tkmb.showinfo(title="Login Successful", message="You have logged in Successfully")
            self.hide()
            self.outer.children[DataSet.__name__].appear()
            
        elif known_user == username or known_pass != password:
            tkmb.showwarning(title='Wrong password', message='Please check your username/password')
            
        else:
            tkmb.showerror(title="Login Failed", message="Invalid Username and password")

    def quit(self):
        if messagebox.askyesnocancel("Confirmation", f"Are you sure you want to exit"):
            self.outer.app.quit()

# landing page (pathway to db data or upload data)
class Landing(BaseTemplate):
    def __init__(self,outer:App) -> None:
        self.visible = False
        self.outer = outer
        master = self.outer.app
        
        self.frame = ctk.CTkScrollableFrame(master=master, fg_color=custom_color_scheme["fg_color"])
        
        ctk.CTkLabel(master=self.frame , text="Select a option:", text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=10)
        ctk.CTkButton(master=self.frame , text='Preview Existing Data', command=self.preview, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=12, padx=10)
        ctk.CTkButton(master=self.frame , text='Upload Excel data', command=self.upload, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=12, padx=10)
        ctk.CTkButton(master=self.frame , text='Send Mail', command=self.mail, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=12, padx=10)
        ctk.CTkButton(master=self.frame , text='Back', command=self.back, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=12, padx=10)

    # back to mysql setup page
    def back(self) -> None:
        self.hide()
        self.outer.children[DataSet.__name__].appear()

    # proceeds to upload page
    def upload(self) -> None:
        self.hide()
        self.outer.children[FileInput.__name__].appear()

    def mail(self) -> None:
        self.hide()
        self.outer.children[Mail.__name__].appear()

    # proceeds to pre-existing data page
    def preview(self) -> None:
        count = self.outer.children[Interface.__name__].available_data()
        if count:
            self.outer.children[Interface.__name__].appear()
            self.hide()
        else:
            tkmb.showerror("MySQL Error","No Data Available to preview")

# the db page
class Interface(BaseTemplate,ExcelFunc):
    def __init__(self,outer:App) -> None:
        self.visible = False
        self.outer = outer
        master = self.outer.app
        self.frame = ctk.CTkScrollableFrame(master=master, fg_color=custom_color_scheme["fg_color"])

        self.entry_year = ctk.StringVar()
        self.entry_month = ctk.StringVar()
        self.entry_institute = ctk.StringVar()
        self.entry_type = ctk.StringVar()
        
        self.entry_year.set('')
        self.entry_month.set('')
        self.entry_institute.set('')
        self.entry_type.set('')

        ctk.CTkLabel(master=self.frame , text="Enter Details", text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=20)
        
        self.entry_instituteList = ctk.CTkOptionMenu(master=self.frame,variable=self.entry_institute,values=[],command=self.changeInstitute,button_color=custom_color_scheme["button_color"],fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250)
        self.entry_instituteList.pack(pady=12, padx=10)
        
        self.entry_typeList = ctk.CTkOptionMenu(master=self.frame,variable=self.entry_type,values=[],command=self.changeType,button_color=custom_color_scheme["button_color"],fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250)
        self.entry_typeList.pack(pady=12, padx=10)
        
        self.entry_yearList = ctk.CTkOptionMenu(master=self.frame,variable=self.entry_year,values=[],command=self.changeYear,button_color=custom_color_scheme["button_color"],fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250)
        self.entry_yearList.pack(pady=12, padx=10)
        
        self.entry_monthList = ctk.CTkOptionMenu(master=self.frame,variable=self.entry_month,values=[],button_color=custom_color_scheme["button_color"],fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250)
        self.entry_monthList.pack(pady=12, padx=10)
        
        ctk.CTkButton(master=self.frame , text='Continue', command=self.getData, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=12, padx=10)
        ctk.CTkButton(master=self.frame , text='Back', command=self.back_to_landing, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=12, padx=10)

    # back to landing
    def back_to_landing(self) -> None:
        self.hide()
        self.outer.children[Landing.__name__].appear()

    # checks db for existing data (abstract?)
    def changeInstitute(self,event:tk.Event) -> None:
        curr_institute = self.entry_institute.get()
        curr_type = list(self.data[curr_institute].keys())
        curr_year = list(self.data[curr_institute][curr_type[0]].keys())
        curr_month = sorted(list(self.data[curr_institute][curr_type[0]][curr_year[0]]),key=lambda x:self.outer.month_order[x])

        # set the values
        self.entry_type.set(curr_type[0])
        self.entry_year.set(curr_year[0])
        self.entry_month.set(curr_month[0])
        
        # Change Lists
        self.entry_typeList.configure(values=curr_type)
        self.entry_yearList.configure(values=curr_year)
        self.entry_monthList.configure(values=curr_month)

    # checks db for existing data
    def available_data(self) -> int:
        self.data = self.outer.db.showTables()
        
        if(self.data):
            self.changeData()
            return True
        else:
            False
    
    # Loads all possible options
    def changeData(self):
        curr_institute = list(self.data.keys())
        curr_type = list(self.data[curr_institute[0]].keys())
        curr_year = list(self.data[curr_institute[0]][curr_type[0]].keys())
        curr_month = sorted(list(self.data[curr_institute[0]][curr_type[0]][curr_year[0]]),key=lambda x:self.outer.month_order[x])
        
        # set the values
        self.entry_institute.set(curr_institute[0])
        self.entry_type.set(curr_type[0])
        self.entry_year.set(curr_year[0])
        self.entry_month.set(curr_month[0])
        
        # Change Lists
        self.entry_instituteList.configure(values=curr_institute)
        self.entry_typeList.configure(values=curr_type)
        self.entry_yearList.configure(values=curr_year)
        self.entry_monthList.configure(values=curr_month)
        
    # updates menu when year changes
    def changeYear(self,event:tk.Event) -> None:
        curr_institute = self.entry_institute.get()
        curr_type = self.entry_type.get()
        curr_year = self.entry_year.get()
        curr_month = sorted(list(self.data[curr_institute][curr_type][curr_year]),key=lambda x:self.outer.month_order[x])

        # set the values
        self.entry_month.set(curr_month[0])
        
        # Change Lists
        self.entry_monthList.configure(values=curr_month)

    # changes type according to institute and checks db for that
    def changeType(self,event:tk.Event):
        curr_institute = self.entry_institute.get()
        curr_type = self.entry_type.get()
        curr_year = list(self.data[curr_institute][curr_type].keys())
        curr_month = sorted(list(self.data[curr_institute][curr_type][curr_year[0]]),key=lambda x:self.outer.month_order[x])

        # set the values
        self.entry_year.set(curr_year[0])
        self.entry_month.set(curr_month[0])
        
        # Change Lists
        self.entry_yearList.configure(values=curr_year)
        self.entry_monthList.configure(values=curr_month)

    # fetches data from the chosen table
    def getData(self) -> None:
        curr_institute = self.entry_institute.get()
        curr_type = self.entry_type.get()
        curr_year = self.entry_year.get()
        curr_month = self.entry_month.get()
        
        self.outer.children[DBFetch.__name__].month = curr_month
        self.outer.children[DBFetch.__name__].year = curr_year
        self.outer.children[DBFetch.__name__].chosen = curr_institute
        self.outer.children[DBFetch.__name__].type_ = curr_type
        self.outer.children[DBFetch.__name__].label_date.configure(text=f"{curr_institute.capitalize()}-{curr_type.capitalize()}-{curr_month.capitalize()}-{curr_year.upper()}")
        
        if self.outer.children[DBFetch.__name__].load_database(curr_month,curr_year,curr_institute,curr_type):
            self.hide()
            self.outer.children[DBFetch.__name__].appear()
        else:
            tkmb.showerror("Database Error"," Cannot fetch data from Database")

# file input page
class FileInput(BaseTemplate,ExcelFunc):
    def __init__(self,outer:App):
        self.visible = False
        self.outer = outer
        master = self.outer.app
        self.frame = ctk.CTkScrollableFrame(master=master, fg_color=custom_color_scheme["fg_color"])
        self.sheets = []
        self.data = pd.DataFrame([])
        self.sheet = ctk.StringVar()
        self.index=0
        self.max_ = 0

        self.sheet.set('')
        
        ctk.CTkLabel(master=self.frame , text="File Upload", text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=10)
        ctk.CTkLabel(master=self.frame , text="Select Excel File:", text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=10)

        self.file = ctk.CTkEntry(master=self.frame , width=100, text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"))
        self.file.pack(pady=5)

        ctk.CTkButton(master=self.frame , text="Browse", command=self.select_file, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=5)

        self.sheetList = ctk.CTkOptionMenu(master=self.frame,variable=self.sheet,values=[],command=self.changeViewing,button_color=custom_color_scheme["button_color"],fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250)
        self.sheetList.pack(pady=12, padx=10)
        
        ctk.CTkLabel(master=self.frame , text="Row Change:", text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=12,padx=10)
        
        frame = ctk.CTkFrame(master=self.frame, fg_color=custom_color_scheme["fg_color"])
        ctk.CTkButton(master=frame , text="-", command=self.prev_row, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=50).pack(side="left",padx=10)
        
        self.row = ctk.CTkLabel(master=frame , text="0", text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=150)
        self.row.pack(side="left",padx=10)
        
        ctk.CTkButton(master=frame , text="+", command=self.next_row, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=50).pack(side="left",padx=10)
        
        frame.pack(pady=12, padx=10)
        
        ctk.CTkButton(master=self.frame , text="Save to DB", command=self.uploadTime, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=10)

        ctk.CTkButton(master=self.frame , text='Back', command=self.back_to_landing, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=12, padx=10)

        self.text_excel = scrolledtext.ScrolledText(master=self.frame, width=90, height=25,  bg="black", fg="white", wrap=tk.NONE, font=("Courier", 12))
        x_scrollbar = Scrollbar(self.frame, orient="horizontal",command=self.text_excel.xview)
        x_scrollbar.pack(side='bottom', fill='x')

        self.text_excel.configure(xscrollcommand=x_scrollbar.set)
        self.text_excel.pack(pady=10,padx=10, fill='both', expand=True)


    # proceeds to uploading page to save data to db
    def uploadTime(self) -> None:
        if self.data.shape[0]:
            self.hide()
            self.outer.children[DBUpload.__name__].data = self.data
            self.outer.children[DBUpload.__name__].sheet.set(self.sheet.get())
            self.outer.children[DBUpload.__name__].file.delete(0, tk.END)
            self.outer.children[DBUpload.__name__].file.insert(0, self.file.get())
            self.outer.children[DBUpload.__name__].file.configure(width=7*len(self.file.get()))
            self.outer.children[DBUpload.__name__].view_excel()
            self.outer.children[DBUpload.__name__].changeType()
            self.outer.children[DBUpload.__name__].appear()
        else:
            tkmb.showwarning("Error", "No data found")

    def changeViewing(self,event: tk.Event)->None:
        ExcelFunc.changeView(self)
        self.index = min(self.index,self.data.shape[0])
        self.row.configure(text=self.index)
        ExcelFunc.changeView(self,skip=self.index)
        self.max_ = 0
        
    # back to landing
    def back_to_landing(self) -> None:
        self.hide()
        self.outer.children[Landing.__name__].appear()

    # dialog to select excel file
    def select_file(self) -> None:
        file_path = filedialog.askopenfilename(filetypes=[("Excel Files", ".xlsx;.xls")])

        if file_path:
            self.file.delete(0, tk.END)
            self.file.insert(0, file_path)
            self.file.configure(width=7*len(file_path))
            self.sheets = list(pd.read_excel(io=self.decryting_wrapper(file_path,prev_password),sheet_name=None).keys())
            self.sheet.set(self.sheets[0])
            self.changeSheets()
            self.index = 0
            self.row.configure(text=self.index)
            self.changeView(skip=self.index)
    
    # used to adjust the start point of excel for proper data entry. decreement by 1.
    def prev_row(self) -> None:
        self.index = max(0,self.index-1)
        self.changeView(skip=self.index)
        self.row.configure(text=self.index)
    
    # used to adjust the start point of excel for proper data entry. increement by 1.
    def next_row(self) -> None:
        self.max_ = max(self.max_,self.data.shape[0]-1)
        self.index = min(self.max_,self.index+1)
        self.changeView(skip=self.index)
        self.row.configure(text=self.index)

# fetching db
class DBFetch(BaseTemplate,ExcelFunc):
    def __init__(self,outer:App):

        self.visible = False
        self.outer = outer
        master = self.outer.app
        
        self.frame = ctk.CTkScrollableFrame(master=master, fg_color=custom_color_scheme["fg_color"])
        self.month = "None"
        self.year = "None"
        self.type_ = "None"
        self.chosen = "None"
        self.data = pd.DataFrame({})
        
        self.label_date = ctk.CTkLabel(master=self.frame , text=f"{self.chosen.capitalize()}-{self.type_.capitalize()}-{self.month.capitalize()}-{self.year.upper()}", text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250)
        self.label_date.pack()
        
        ctk.CTkLabel(master=self.frame , text="Enter Employee ID:", text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250).pack()

        self.entry_id = ctk.CTkEntry(master=self.frame , text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250)
        self.entry_id.pack(pady=5)

        ctk.CTkButton(master=self.frame , text="Generate Single PDF", command=self.extract_data_cover, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=10)
        ctk.CTkButton(master=self.frame , text="Bulk Print PDFs", command=self.bulk_print_pdfs_cover, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=10)
        ctk.CTkButton(master=self.frame , text="Copy Row to Clipboard", command=self.copy_row_to_clipboard, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=10)
        ctk.CTkButton(master=self.frame , text='Back', command=self.back_to_interface, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=12, padx=10)

        self.text_excel = scrolledtext.ScrolledText(master=self.frame, width=90, height=25,  bg="black", fg="white", wrap=tk.NONE, font=("Courier", 12))
        x_scrollbar = Scrollbar(self.frame, orient="horizontal",command=self.text_excel.xview)

        x_scrollbar.pack(side='bottom', fill='x')

        self.text_excel.configure(xscrollcommand=x_scrollbar.set)
        self.text_excel.pack(pady=10,padx=10, fill='both', expand=True)

    # back to interface
    def back_to_interface(self) -> None:
        self.hide()
        self.outer.children[Interface.__name__].appear()

    # cover for extract_data
    def extract_data_cover(self) -> None:
        month = self.month
        year = self.year
        insti = self.chosen
        type_ = self.type_
        id = self.entry_id.get()
        
        if id:
            ExcelFunc.extract_data(self=self,employee_data=self.data,who=id,month=month,year=year,type_=type_,chosen=insti)
        else:
            tkmb.showerror("Empty Data","Empty Search String Detected")
            
    # cover for bulk_print_pdfs
    def bulk_print_pdfs_cover(self) -> None:
        month = self.month
        year = self.year
        insti = self.chosen
        type_ = self.type_
        
        ExcelFunc.bulk_print_pdfs(self=self,employee_data=self.data,month=month,year=year,type_=type_,chosen=insti)

# uploading data to db 
class DBUpload(BaseTemplate,ExcelFunc):
    def __init__(self,outer:App):

        self.visible = False
        self.outer = outer
        master = self.outer.app
        self.frame = ctk.CTkScrollableFrame(master=master, fg_color=custom_color_scheme["fg_color"])
        self.data = pd.DataFrame([])
        self.sheet = ctk.StringVar()
        self.chosen = ctk.StringVar()
        self.type_ = ctk.StringVar()
        self.month = ctk.StringVar()

        self.type_.set('Teaching')
        self.chosen.set('Somaiya')
        self.month.set('Jan')
        
        ctk.CTkLabel(master=self.frame , text="Selected Excel File:", text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=10)

        self.file = ctk.CTkEntry(master=self.frame , width=100, text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"))
        self.file.pack(pady=5)

        ctk.CTkOptionMenu(master=self.frame,variable=self.chosen,values=["Somaiya", "SVV"],command=self.changeType,button_color=custom_color_scheme["button_color"],fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=12, padx=10)
        self.toggle_type  = ctk.CTkOptionMenu(master=self.frame,variable=self.type_,values=[],button_color=custom_color_scheme["button_color"],fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250)
        self.toggle_type.pack(pady=12, padx=10)

        ctk.CTkOptionMenu(master=self.frame,variable=self.month,values=["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"],button_color=custom_color_scheme["button_color"],fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=12, padx=10)
        ctk.CTkLabel(master=self.frame,text="Enter Year:", text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250).pack()
        
        self.year = ctk.CTkEntry(master=self.frame , placeholder_text="Eg. 2024",text_color=custom_color_scheme["text_color"], font=("Ubuntu", 16, "bold"),width=250)
        self.year.pack()

        ctk.CTkButton(master=self.frame , text="Upload to DB",command=self.upload, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=10)
        ctk.CTkButton(master=self.frame , text="Delete from DB",command=self.deload, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=10)
        ctk.CTkButton(master=self.frame , text='Back', command=self.back_to_view, fg_color=custom_color_scheme["button_color"], font=("Ubuntu", 16, "bold"),width=250).pack(pady=12, padx=10)

        self.text_excel = scrolledtext.ScrolledText(master=self.frame, width=90, height=25,  bg="black", fg="white", wrap=tk.NONE, font=("Courier", 12))
        x_scrollbar = Scrollbar(self.frame, orient="horizontal",command=self.text_excel.xview)

        x_scrollbar.pack(side='bottom', fill='x')

        self.text_excel.configure(xscrollcommand=x_scrollbar.set)
        self.text_excel.pack(pady=10,padx=10, fill='both', expand=True)

    # drops table (caution)
    def deload(self) -> None:
        if year_check(self.year.get()):
            year = int(self.year.get())
        else:
            tkmb.showwarning("Alert","Incorrect year format")
            return
        
        month = self.month.get()
        sheet = self.sheet.get()
        chosen = self.chosen.get().lower()
        type_ = self.type_.get().lower()
        database = self.outer.db

        if year and sheet and month and chosen and type_ and messagebox.askyesnocancel("Confirmation", f"Month: {month}, Year: {year} \n Institue:{ chosen}, Type: {type_} \n Are you sure you want to clear this data from DB?"):

            if messagebox.askyesnocancel("Warning","Once data is dropped it cannot be retrieved. Are you sure about this?") and messagebox.askyesnocancel("Warning","Are you sure about this again?"):
                result = database.dropTable(chosen,type_,month,year)
                if result:
                    tkmb.showinfo("Alert", "Table dropped")
                elif result is not None:
                    tkmb.showinfo("Alert", "Table does not exists")
                else:
                    tkmb.showinfo("Alert", "MySQL Error Occured")

    # uploads data to db
    def upload(self) -> None:
        if year_check(self.year.get()):
            year = int(self.year.get())
        else:
            tkmb.showwarning("Alert","Incorrect year format")
            return
        
        month = self.month.get()
        sheet = self.sheet.get()
        chosen = self.chosen.get().lower()
        type_ = self.type_.get().lower()
        database = self.outer.db

        if year and sheet and month and chosen and type_ and messagebox.askyesnocancel("Confirmation", f"Month: {month}, Year: {year} \n Institue: { chosen}, Type: {type_} \n Are you sure details are correct?"):
            can_create = database.createData(month,year,self.data.columns,chosen,type_)
            if can_create==1:
                tkmb.showinfo("Alert", "Table created")

                res = database.updateData(self.data,month,year,chosen,type_)
                match res:
                    case -1: tkmb.showinfo("Upload","Columns don't match with table's columns")
                    case 0: tkmb.showwarning('Error',"HR EMP CODE not found / MySQL connection failed!")
                    case 1: tkmb.showinfo("Upload","Data Upload was successfully")

            elif can_create==2:
                response = messagebox.askyesnocancel("Table exists", "This data already exists. Would you like to update it?")

                if response:
                    res = database.updateData(self.data,month,year,chosen,type_)
                    match res:
                        case -1: tkmb.showinfo("Upload","Columns don't match with table's columns")
                        case 0: tkmb.showwarning('Error',"HR EMP CODE not found / MySQL connection failed!")
                        case 1: tkmb.showinfo("Upload","Data Upload was successfully")
                else:
                    tkmb.showinfo("Upload","Data upload aborted")
                    
            elif can_create==3:
                tkmb.showwarning('Error',"MySQL connection failed!")
            elif can_create==-1:
                tkmb.showwarning('Error',"Duplicate Columns Found")
            else:
                tkmb.showwarning('Error',"HR EMP Code column not found!")


    # back to view
    def back_to_view(self) -> None:
        self.hide()
        self.outer.children[FileInput.__name__].appear()

# Apply custom colors
custom_color_scheme = {
    "fg_color": "white",
    "button_color": "dark red",
    "text_color": "black",
    "combo_box_color": "white"  # Added for combo box color
}

# initialize main app
app = App()

# running app
app.app.mainloop()

try:
    app.app.destroy()
except:
    print(' o7')

try:
    app.db.endDatabase()
except Exception as e:
    print(e)
